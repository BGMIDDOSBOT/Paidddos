sudo apt update
sudo apt install python3-pip -y
pip install fastapi psutil
sudo apt install unzip -y
unzip dist.zip